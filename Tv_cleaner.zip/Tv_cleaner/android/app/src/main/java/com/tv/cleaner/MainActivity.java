package com.tv.cleaner;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
